package com.legent.onthebeat

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.platform.LocalContext
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.common.Player
import android.content.Intent
import android.net.Uri

data class Track(
    val title: String,
    val artist: String = "Legent On The Beat",
    val audioUrl: String = "",
    val coverUrl: String = ""
)

private val tracks = listOf(
    Track("Navy Seal Riddim"),
    Track("Air Force Riddim"),
    Track("Spatial Riddim"),
    Track("Sapatina Riddim")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LegentApp() }
    }
}

@Composable
fun LegentApp() {
    val context = LocalContext.current
    var selected by remember { mutableStateOf<Track?>(null) }
    var query by remember { mutableStateOf("") }
    var playing by remember { mutableStateOf(false) }

    val player = remember {
        ExoPlayer.Builder(context).build().apply {
            addListener(object : Player.Listener {
                override fun onIsPlayingChanged(isPlaying: Boolean) {
                    playing = isPlaying
                }
            })
        }
    }

    DisposableEffect(Unit) {
        onDispose { player.release() }
    }

    val filtered = tracks.filter {
        it.title.contains(query, ignoreCase = true)
    }

    MaterialTheme {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("Legent On The Beat", fontWeight = FontWeight.Bold)
                            Text("Online Music", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                )
            },
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(true, {}, icon = {}, label = { Text("Home") })
                    NavigationBarItem(false, {}, icon = {}, label = { Text("Beats") })
                    NavigationBarItem(false, {}, icon = {}, label = { Text("About") })
                }
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.padding(padding).fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Text("Latest Riddims", style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        label = { Text("Search music") }
                    )
                }

                items(filtered) { track ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(18.dp)
                    ) {
                        Column(Modifier.padding(16.dp)) {
                            Text(track.title, fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleLarge)
                            Text(track.artist)
                            Spacer(Modifier.height(10.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = {
                                    if (track.audioUrl.isBlank()) {
                                        selected = track
                                    } else {
                                        player.setMediaItem(MediaItem.fromUri(track.audioUrl))
                                        player.prepare()
                                        player.play()
                                        selected = track
                                    }
                                }) {
                                    Text("▶ Play")
                                }
                                OutlinedButton(onClick = {
                                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(track.audioUrl))
                                    if (track.audioUrl.isNotBlank()) context.startActivity(intent)
                                }) {
                                    Text("Download")
                                }
                            }
                        }
                    }
                }

                item {
                    Spacer(Modifier.height(8.dp))
                    HorizontalDivider()
                    Spacer(Modifier.height(12.dp))
                    Text("Booking / Contact", fontWeight = FontWeight.Bold)
                    Text("0779653285")
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = {
                        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:0779653285"))
                        context.startActivity(intent)
                    }) { Text("Call Legent") }
                }

                selected?.let { track ->
                    item {
                        Card {
                            Column(Modifier.padding(16.dp)) {
                                Text("Now Selected", fontWeight = FontWeight.Bold)
                                Text(track.title)
                                Text(
                                    if (track.audioUrl.isBlank())
                                        "Add an online MP3 URL in MainActivity.kt to play this track."
                                    else "Playing online"
                                )
                                if (track.audioUrl.isNotBlank()) {
                                    Button(onClick = {
                                        if (playing) player.pause() else player.play()
                                    }) {
                                        Text(if (playing) "Pause" else "Play")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
