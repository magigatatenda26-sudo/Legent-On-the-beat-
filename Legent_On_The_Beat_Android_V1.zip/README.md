# Legent On The Beat — Android Version 1

Features:
- Online music player using Android Media3/ExoPlayer
- Search
- Riddims list
- Booking phone button: 0779653285
- Download/open URL button
- Ready for Firebase/Supabase integration

## Add your music
Open:
`app/src/main/java/com/legent/onthebeat/MainActivity.kt`

For each Track, put a direct HTTPS MP3 URL in `audioUrl`.

Example:
Track(
    "Navy Seal Riddim",
    audioUrl = "https://your-domain.com/music/navy-seal.mp3"
)

## Build
Open the project in Android Studio and let Gradle sync.
Then Build > Generate App Bundle/APK.
